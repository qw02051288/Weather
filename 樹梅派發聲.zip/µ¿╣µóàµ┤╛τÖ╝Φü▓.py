#!/usr/bin/python

import RPi.GPIO as GPIO
import time
import requests
import re
import os
from gtts import gTTS

regex = r"<td>(.*) %<\/td>"

GPIO.setmode(GPIO.BOARD)
pir = 7
GPIO.setup(pir, GPIO.IN)
print("Sensor initializing . . .")
time.sleep(2)
print("Active")
print("Press Ctrl+c to end program")

def play_sound():
    req = requests.request('GET', 'https://www.cwb.gov.tw/V7/forecast/taiwan/New_Taipei_City.htm')
    matches = re.search(regex, req.text)
    print(matches.groups()[0])
    rain_chance = int(matches.groups()[0])
    if rain_chance < 40:
        rain_stat = '不會下雨'
    else:
        rain_stat = '可能會下雨'

    tts = gTTS(text=rain_stat + '，降雨機率約' + str(rain_chance) + '%', lang='zh-tw')
    tts.save("rain.mp3")
    os.system('omxplayer ./rain.mp3')

try:
    while True:
        if GPIO.input(pir) == True:  #If PIR pin goes high, motion is detected
            print("Motion Detected!")
            play_sound()
            time.sleep(20)
            last_pir = GPIO.input(pir)

except KeyboardInterrupt:
    pass

finally:
    GPIO.cleanup()
    pygame.quit()
    print("Program ended")
